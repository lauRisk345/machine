# Machine Learning LAB · Proyecto Nepal — Vercel

Esta carpeta es una **vista web estática interactiva** del laboratorio académico original desarrollado en Python + Streamlit. Usa exclusivamente la base Nepal, las técnicas del ZIP original y resultados precalculados por el motor Python (`core.py`).

## Publicar en Vercel con una sola subida

1. Abre https://vercel.com/drop e inicia sesión en tu cuenta de Vercel.
2. Sube el archivo **ML_LAB_Nepal_Vercel.zip** que contiene `index.html`, `app.js`, `styles.css` y `data/` en su raíz.
3. Selecciona el equipo y un nombre (por ejemplo, `ml-lab-nepal`).
4. Pulsa **Deploy**. Vercel publicará un sitio estático (no requiere variables de entorno, Node, build ni Python).
5. Abre la URL `*.vercel.app` que Vercel genere.

También puedes importar el contenido de esta carpeta como repositorio GitHub en Vercel. Si usas Import Project, elige **Framework Preset = Other**, **Build Command vacío** y **Root Directory = /**. No publiques el ZIP original completo como si fuera un proyecto HTML; contiene Python, R y recursos que no se sirven así.

## Qué funciona

- Dashboard de la base Nepal de **5.000 registros, 48 variables**.
- EDA realizada en navegador: filas, nulos, tipos, frecuencias, intervalos, carga de CSV.
- Regresión logística: umbral ajustable y **métricas de prueba recalculadas al mover el umbral** usando las 1.500 observaciones/ probabilidades del ajuste real.
- Árboles: comparación de tres profundidades con métricas precalculadas en Python.
- Clustering: proyecciones de K-Means para K=3,4,5 y muestra de clustering jerárquico Ward.
- PCA: cargas, proporción de varianza explicada y proyección.
- Simulador: cálculo **real en navegador de la ecuación logística**, con intercepto, coeficientes y codificación categórica/escala del entrenamiento Python.
- Quiz, bitácora local y exportación JSON.

## Qué NO funciona en Vercel

El entrenamiento completo de modelos Python/R, análisis AFC/SEM con R, ejecución de notebooks y Excel, y las herramientas científicas avanzadas de la aplicación Streamlit **no están incluidas** en la web estática. Esta web es para **visualizar, explorar y ensayar los resultados**. Si se necesita entrenar nuevos modelos con CSV/Excel, usar la aplicación local `Machine_Learning_LAB_Nepal.zip`, o implementar después un backend Python en hosting adecuado.

> Estadísticas y predicciones estadísticas no son evidencia de causalidad ni constituyen una evaluación de seguridad estructural certificada. El modelo no predice terremotos.

**Privacidad:** La base `Base_Nepal_5000.csv` forma parte del sitio estático y cualquier visitante con acceso al sitio puede descargarla. Los CSV cargados para EDA se procesan en el navegador y no se envían a nuestro servidor. Las notas y la bitácora se guardan en el localStorage del navegador donde se utiliza.
